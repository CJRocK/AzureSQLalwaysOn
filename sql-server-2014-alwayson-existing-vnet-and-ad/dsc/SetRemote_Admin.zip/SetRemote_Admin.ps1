Param
(
[Parameter(Mandatory=$true)][String]$MembersId,
[Parameter(Mandatory=$true)][String]$Username,
[Parameter(Mandatory=$true)][securestring]$Password,
[Parameter(Mandatory=$true)][String]$DomainName,    #="internal.towerswatson.com"
[Parameter(Mandatory=$true)][String]$DomainNetbiosName     #="internal"
)

$ConfigData = @{
    AllNodes = @(
        @{
            NodeName="localhost";
            PSDscAllowPlainTextPassword = $true
            
         }
)}

configuration AllowRemoteDesktopAdminConnections
{
  
#[System.Management.Automation.PSCredential]$Credentials=Get-Credential

[System.Management.Automation.PSCredential]$DomainCreds =[Parameter(Mandatory=$true)][String]$Username, ("${DomainNetbiosName}\$($Username)", $Password)
[String]$DomainMember=$DomainNetbiosName+"\"+$MembersId
    node ('localhost')
    {        
        Group ConfigureRDPGroup
        {
           Ensure = 'Present'
           GroupName = "Remote Desktop Users"
           Members = $DomainMember #'internal\manis549','internal\cheta678'
           Credential = $DomainCreds
        }
    
        Group Admin
        {
           Ensure = 'Present'
           GroupName = "Administrators"
           Members = $DomainMember #'internal\manis549'
           Credential = $DomainCreds

        }
        
    }
}
$workingdir = 'C:\DSC\MOF'
AllowRemoteDesktopAdminConnections -ConfigurationData $ConfigData -OutputPath $workingdir
Start-DscConfiguration -ComputerName 'localhost' -wait -force -verbose -path $workingdir